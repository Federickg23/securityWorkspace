#!/bin/bash

rm -rf "$1"
	mkdir "$1"

cd "$1" 

mkdir bin mail inputs tmp lib

cd mail 

mkdir addleness analects anthropomorphologically blepharosphincterectomy corector durwaun dysphasia encampment endoscopic exilic forfend gorbellied gushiness muermo neckar outmate outroll overrich philosophicotheological pockwood polypose refluxed reinsure repine scerne starshine unauthoritativeness	unminced unrosed untranquil urushinic vegetocarbonaceous wamara whaledom  

cd ../inputs
